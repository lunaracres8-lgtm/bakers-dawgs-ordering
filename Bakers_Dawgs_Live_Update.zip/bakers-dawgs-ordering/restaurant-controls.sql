-- Baker's Dawgs live restaurant controls
-- Run once in the connected Supabase SQL editor.

create table if not exists public.restaurant_settings (
  id integer primary key default 1 check (id = 1),
  ordering_open boolean not null default true,
  prep_minutes integer not null default 20 check (prep_minutes between 10 and 120),
  updated_at timestamptz not null default now()
);
insert into public.restaurant_settings(id,ordering_open) values (1,true) on conflict (id) do nothing;

create table if not exists public.menu_availability (
  item_name text primary key,
  available boolean not null default true,
  updated_at timestamptz not null default now()
);

alter table public.restaurant_settings enable row level security;
alter table public.menu_availability enable row level security;

drop policy if exists "Anyone can read restaurant settings" on public.restaurant_settings;
drop policy if exists "Staff can update restaurant settings" on public.restaurant_settings;
drop policy if exists "Anyone can read menu availability" on public.menu_availability;
drop policy if exists "Staff can manage menu availability" on public.menu_availability;

create policy "Anyone can read restaurant settings" on public.restaurant_settings for select to anon, authenticated using (true);
create policy "Staff can update restaurant settings" on public.restaurant_settings for update to authenticated
using (auth.uid()='e915fbd7-f087-471a-8a22-1c544ab6a263'::uuid)
with check (auth.uid()='e915fbd7-f087-471a-8a22-1c544ab6a263'::uuid);

create policy "Anyone can read menu availability" on public.menu_availability for select to anon, authenticated using (true);
create policy "Staff can manage menu availability" on public.menu_availability for all to authenticated
using (auth.uid()='e915fbd7-f087-471a-8a22-1c544ab6a263'::uuid)
with check (auth.uid()='e915fbd7-f087-471a-8a22-1c544ab6a263'::uuid);

grant select on public.restaurant_settings, public.menu_availability to anon, authenticated;
grant update on public.restaurant_settings to authenticated;
grant insert, update, delete on public.menu_availability to authenticated;

-- Editable menu builder: items can be added, changed, or deleted from the owner screen.
create table if not exists public.menu_items (
  id text primary key,
  category text not null,
  item_name text not null,
  description text not null default '',
  price numeric(10,2) not null check (price >= 0),
  available boolean not null default true,
  sort_order integer not null default 0,
  updated_at timestamptz not null default now()
);
alter table public.menu_items enable row level security;
drop policy if exists "Anyone can read menu items" on public.menu_items;
drop policy if exists "Staff can manage menu items" on public.menu_items;
create policy "Anyone can read menu items" on public.menu_items for select to anon, authenticated using (true);
create policy "Staff can manage menu items" on public.menu_items for all to authenticated
using (auth.uid()='e915fbd7-f087-471a-8a22-1c544ab6a263'::uuid)
with check (auth.uid()='e915fbd7-f087-471a-8a22-1c544ab6a263'::uuid);
grant select on public.menu_items to anon, authenticated;
grant insert, update, delete on public.menu_items to authenticated;

-- Optional customer-facing daily special.
alter table public.business_branding add column if not exists special_enabled boolean not null default false;
alter table public.business_branding add column if not exists special_title text not null default '';
alter table public.business_branding add column if not exists special_message text not null default '';

insert into public.menu_items (id,category,item_name,description,price,sort_order) values
('hot-1','Hot Dawgs','Carolina Classic Hot Dawg','Mustard, homemade homestyle slaw, chili and onions',3.28,1),
('hot-2','Hot Dawgs','Sauerkraut & Mustard Dawg','Sauerkraut and mustard',3.28,2),
('hot-3','Hot Dawgs','Chili & Cheez Dawg','Chili and cheese',3.28,3),
('hot-4','Hot Dawgs','Chili, Onion & Mustard Dawg','Chili, onions and mustard',3.28,4),
('hot-5','Hot Dawgs','Sweet Relish & Mustard Dawg','Sweet relish and mustard',3.28,5),
('hot-6','Hot Dawgs','Loaded Hot Dawg','Choose 6–8 toppings',4.25,6),
('combo-1','Hot Dawg Combos','Carolina Classic Hot Dawg Combo','Hot Dawg, bag of chips, and drink • $7.00 total with tax',6.56,7),
('combo-2','Hot Dawg Combos','Sauerkraut & Mustard Dawg Combo','Hot Dawg, bag of chips, and drink • $7.00 total with tax',6.56,8),
('combo-3','Hot Dawg Combos','Chili & Cheez Dawg Combo','Hot Dawg, bag of chips, and drink • $7.00 total with tax',6.56,9),
('combo-4','Hot Dawg Combos','Chili, Onion & Mustard Dawg Combo','Hot Dawg, bag of chips, and drink • $7.00 total with tax',6.56,10),
('combo-5','Hot Dawg Combos','Sweet Relish & Mustard Dawg Combo','Hot Dawg, bag of chips, and drink • $7.00 total with tax',6.56,11),
('sausage-1','Smoked Sausages','Brat / Bratwurst','German smoked sausage',6.00,12),
('sausage-2','Smoked Sausages','Classic Plain Smoked Sausage','Johnsonville smoked sausage',6.00,13),
('sausage-3','Smoked Sausages','Cheddar Cheez Smoked Sausage','Cheddar cheese smoked sausage',6.00,14),
('sausage-4','Smoked Sausages','Jalapeño Smoked Sausage','Jalapeño smoked sausage',6.00,15),
('sausage-5','Smoked Sausages','The Perfect Brat','BBQ sauce, sauerkraut and fresh chopped onions',6.00,16),
('sandwich-1','Sandwiches','Grilled Bologna on Toast (cut #5)','Choice of mustard, mayo and slaw',4.50,17),
('sandwich-2','Sandwiches','Grilled Cheez Quesadilla','Optional chili add-on',4.00,18),
('drink-1','Drinks & Sides','Bottled Drink / Soda','',2.00,19),
('drink-2','Drinks & Sides','Bottled Water','',1.50,20),
('drink-3','Drinks & Sides','Sweet Tea with Ice','Homemade sweet tea • No refills',1.75,21),
('drink-4','Drinks & Sides','Lemonade Sweet Tea with Ice','Made with our homemade sweet tea • No refills',2.75,22),
('drink-5','Drinks & Sides','Chips','',1.80,23),
('cake-1','Cakes','German Chocolate Cake','Year-round • $5 per slice',5.00,24),
('cake-2','Cakes','3 Milks Cake','Fall only • evaporated milk • condensed milk • heavy cream',5.00,25)
on conflict (id) do nothing;
