
async function applyBusinessBranding(){
 let b=null;
 try{const cloud=await bdGetBusinessBranding();if(cloud)b={businessName:cloud.business_name,tagline:cloud.tagline,phone:cloud.phone,email:cloud.email,logo:cloud.logo_url,background:cloud.background_url,primary:cloud.primary_color,accent:cloud.accent_color,specialEnabled:cloud.special_enabled,specialTitle:cloud.special_title,specialMessage:cloud.special_message};}catch(e){}
 if(!b){try{b=JSON.parse(localStorage.getItem("bdBusinessBranding")||"{}");}catch(e){b={};}}
 if(!b||!Object.keys(b).length)return;
 localStorage.setItem("bdBusinessBranding",JSON.stringify(b));
 const name=b.businessName||"Baker's Dawgs";
 const title=document.getElementById("brandBusinessNameDisplay");if(title)title.textContent=name.toUpperCase();
 const foot=document.getElementById("brandFooterName");if(foot)foot.textContent=name;
 if(b.primary)document.documentElement.style.setProperty("--brand-primary",b.primary);
 if(b.accent)document.documentElement.style.setProperty("--brand-accent",b.accent);
 if(b.background){document.body.style.backgroundImage='linear-gradient(rgba(0,0,0,.28),rgba(0,0,0,.28)),url("'+String(b.background).replace(/["']/g,"")+'")';document.body.style.backgroundSize="cover";document.body.style.backgroundAttachment="fixed";}
 if(b.logo){let logo=document.getElementById("customBrandLogo");if(!logo){logo=document.createElement("img");logo.id="customBrandLogo";logo.alt=name+" logo";logo.style.cssText="max-width:140px;max-height:100px;object-fit:contain;display:block;margin:0 auto 8px";document.querySelector("header")?.prepend(logo);}logo.src=b.logo;}
 const existingSpecial=document.getElementById("customTodaySpecial");if(b.specialEnabled&&(b.specialTitle||b.specialMessage)){const card=existingSpecial||document.createElement("div");card.id="customTodaySpecial";card.className="cakePromo customTodaySpecial";card.innerHTML=`<b>${String(b.specialTitle||"Today’s Special").replace(/[<>&]/g,"")}</b><span>${String(b.specialMessage||"").replace(/[<>&]/g,"")}</span>`;if(!existingSpecial)document.querySelector(".deliveryNotice")?.insertAdjacentElement("afterend",card);}else existingSpecial?.remove();
 document.title=name+" | Order Ahead";
}

const defaultMenu=[
["Hot Dawgs","Carolina Classic Hot Dawg","Mustard, homemade homestyle slaw, chili and onions",3.28],
["Hot Dawgs","Sauerkraut & Mustard Dawg","Sauerkraut and mustard",3.28],
["Hot Dawgs","Chili & Cheez Dawg","Chili and cheese",3.28],
["Hot Dawgs","Chili, Onion & Mustard Dawg","Chili, onions and mustard",3.28],
["Hot Dawgs","Sweet Relish & Mustard Dawg","Sweet relish and mustard",3.28],
["Hot Dawgs","Loaded Hot Dawg","Choose 6–8 toppings",4.25],
["Hot Dawg Combos","Carolina Classic Hot Dawg Combo","Hot Dawg, bag of chips, and drink • $7.00 total with tax",6.56],
["Hot Dawg Combos","Sauerkraut & Mustard Dawg Combo","Hot Dawg, bag of chips, and drink • $7.00 total with tax",6.56],
["Hot Dawg Combos","Chili & Cheez Dawg Combo","Hot Dawg, bag of chips, and drink • $7.00 total with tax",6.56],
["Hot Dawg Combos","Chili, Onion & Mustard Dawg Combo","Hot Dawg, bag of chips, and drink • $7.00 total with tax",6.56],
["Hot Dawg Combos","Sweet Relish & Mustard Dawg Combo","Hot Dawg, bag of chips, and drink • $7.00 total with tax",6.56],
["Smoked Sausages","Brat / Bratwurst","German smoked sausage",6.00],
["Smoked Sausages","Classic Plain Smoked Sausage","Johnsonville smoked sausage",6.00],
["Smoked Sausages","Cheddar Cheez Smoked Sausage","Cheddar cheese smoked sausage",6.00],
["Smoked Sausages","Jalapeño Smoked Sausage","Jalapeño smoked sausage",6.00],
["Smoked Sausages","The Perfect Brat","BBQ sauce, sauerkraut and fresh chopped onions",6.00],
["Sandwiches","Grilled Bologna on Toast (cut #5)","Choice of mustard, mayo and slaw",4.50],
["Sandwiches","Grilled Cheez Quesadilla","Optional chili add-on",4.00],
["Drinks & Sides","Bottled Drink / Soda","",2.00],
["Drinks & Sides","Bottled Water","",1.50],
["Drinks & Sides","Sweet Tea with Ice","Homemade sweet tea • No refills",1.75],
["Drinks & Sides","Lemonade Sweet Tea with Ice","Made with our homemade sweet tea • No refills",2.75],
["Drinks & Sides","Chips","",1.80],
["Cakes","German Chocolate Cake","Year-round • $5 per slice",5.00],
["Cakes","3 Milks Cake","Fall only • evaporated milk • condensed milk • heavy cream",5.00]
];
let menu=defaultMenu.map(item=>[...item]);

const toppings=[
"Yellow Mustard","Spicy Mustard","Chili","Cheese",
"Fresh Onions","Homestyle Slaw","Sauerkraut","Sweet Relish",
"Grilled Onions","Grilled Green Peppers","BBQ Sauce"
];

let cart=JSON.parse(localStorage.getItem("bdCart")||"[]");
let active=null;
let orderingOpen=true;
let orderingStatusKnown=false;
let prepMinutes=20;
let menuAvailability={};
let lastCustomer=JSON.parse(localStorage.getItem("bdCustomer")||"{}");
const money=n=>"$"+n.toFixed(2);
const TAX_RATE=0.0675;
const taxFor=subtotal=>Math.round(subtotal*TAX_RATE*100)/100;
const totalWithTax=subtotal=>Math.round((subtotal+taxFor(subtotal))*100)/100;
let cats=[...new Set(menu.map(x=>x[0]))];

const menuEl=document.querySelector("#menu");

function render(cat){
 menuEl.innerHTML=cats.filter(c=>!cat||c===cat).map(c=>
 `<section class="category">
 <h2>${c}</h2>
 <div class="grid">${
 menu.map((x,i)=>x[0]===c?
 `<article class="item ${menuAvailability[x[1]]===false?"soldout":""}">
 <div class="foodIcon">${(c==="Hot Dawgs"||c==="Hot Dawg Combos")?"🌭":c==="Smoked Sausages"?"🔥":c==="Sandwiches"?"🥪":c==="Cakes"?"🍰":"🥤"}</div>
 <h3>${x[1]}</h3>
 <p class="desc">${x[2]}</p>
 <div class="price">${money(x[3])} <small>+ tax</small></div>
 ${menuAvailability[x[1]]===false?`<div class="soldoutLabel">SOLD OUT</div><button class="add" disabled>Sold Out</button>`:`<button class="add" onclick="customize(${i})">Customize & Add</button>`}
 </article>`:"").join("")
 }</div></section>`).join("");
}


function returnToAdmin(){
 sessionStorage.removeItem("bdReturnToAdmin");
 location.href="admin.html";
}
function showStaffReturnIfLocked(){
 const params=new URLSearchParams(location.search);
 const locked=params.get("admin_locked")==="1" || sessionStorage.getItem("bdReturnToAdmin")==="1";
 const box=document.querySelector("#staffReturn");
 if(box) box.classList.toggle("hidden",!locked);
}

function goMenu(){
 if(orderingStatusKnown&&!orderingOpen) return showOrderingPaused();
 render();
 menuEl.scrollIntoView({behavior:"smooth"});
}

function showCat(c){
 render(c);
 menuEl.scrollIntoView();
}

function customize(i){
 if(menuAvailability[menu[i][1]]===false) return alert("Sorry, that item is sold out right now.");
 if(orderingStatusKnown&&!orderingOpen) return showOrderingPaused();
 active=i;
 let x=menu[i];
 let food=x[0]==="Hot Dawgs"||x[0]==="Smoked Sausages";
 let ques=x[1].includes("Quesadilla");

 modalBody.innerHTML=
 `<h2>${x[1]}</h2>
 <div class="bigprice">${money(x[3])} <small>+ tax</small></div>
 <p>${x[2]}</p>
 ${food?`<h3>Toppings</h3>
 <div class="checks">${
 toppings.map(t=>`<label><input type="checkbox" value="${t}"> ${t}</label>`).join("")
 }</div>`:""}
 ${ques?'<label><input id="chiliAdd" type="checkbox"> Add chili +$0.50</label>':""}
 <label class="label">Special instructions</label>
 <textarea id="itemNotes" class="field" placeholder="Example: no onions, extra mustard"></textarea>
 <label class="label">Quantity</label>
 <input id="qty" class="field" type="number" min="1" max="20" value="1">
 <button class="checkout" onclick="addCustomized()">Add to Order</button>`;

 openModal();
}

function addCustomized(){
 let q=Math.max(1,+qty.value||1);
 let tops=[...document.querySelectorAll(".checks input:checked")].map(x=>x.value);
 let notes=itemNotes.value;
 let extra=document.querySelector("#chiliAdd")?.checked?.5:0;

 for(let n=0;n<q;n++){
  cart.push({i:active,tops,notes,extra});
 }

 save();
 closeModal();
}

function save(){
 localStorage.setItem("bdCart",JSON.stringify(cart));
 update();
}

function update(){
 cartCount.textContent=cart.length;
 const subtotal=cart.reduce((s,x)=>s+menu[x.i][3]+(x.extra||0),0);
 cartTotal.textContent=totalWithTax(subtotal).toFixed(2);
}

function pickupOptions(){
 const now=new Date();
 now.setMinutes(now.getMinutes()+prepMinutes);
 const rounded=Math.ceil(now.getMinutes()/15)*15; now.setMinutes(rounded,0,0);
 let out=`<option value="">Choose a pickup time</option>`;
 for(let i=0;i<16;i++){
  const d=new Date(now.getTime()+i*15*60000);
  const value=d.toTimeString().slice(0,5);
  const label=d.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"});
  out+=`<option value="${value}">${label}</option>`;
 }
 return out;
}

function showOrderingPaused(){
 modalBody.innerHTML=`<h2>Online Ordering Is Paused</h2><p>Baker’s Dawgs is not accepting online pickup orders right now. Please check back soon.</p><button class="checkout" onclick="closeModal()">OK</button>`;
 openModal();
}

async function refreshMenuAvailability(){
 try{
  const rows=await bdGetMenuAvailability();
  menuAvailability=Object.fromEntries((rows||[]).map(r=>[r.item_name,r.available!==false]));
  render();
 }catch(e){}
}
async function loadEditableMenu(){
 try{
  const rows=await bdGetMenuItems();
  if(!rows?.length)return;
  menu=rows.sort((a,b)=>(a.sort_order||0)-(b.sort_order||0)).map(x=>[x.category,x.item_name,x.description||"",Number(x.price)]);
  cats=[...new Set(menu.map(x=>x[0]))];
  menuAvailability=Object.fromEntries(rows.map(x=>[x.item_name,x.available!==false]));
  render();update();
 }catch(e){}
}

async function refreshOrderingStatus(){
 try{
  const settings=await bdGetRestaurantSettings();
  orderingOpen=settings?.ordering_open!==false;
  prepMinutes=Number(settings?.prep_minutes)||20;
  orderingStatusKnown=true;
  document.body.classList.toggle("ordering-paused",!orderingOpen);
  const hero=document.querySelector(".hero");
  if(hero){ hero.textContent=orderingOpen?"ORDER FOR PICKUP":"ONLINE ORDERING PAUSED"; hero.disabled=!orderingOpen; }
  const banner=document.querySelector("#orderingBanner");
  if(banner){ banner.classList.toggle("hidden",orderingOpen); }
 }catch(e){
  orderingStatusKnown=false;
 }
}

function openCart(){
 if(orderingStatusKnown&&!orderingOpen) return showOrderingPaused();
 let subtotal=cart.reduce((s,x)=>s+menu[x.i][3]+(x.extra||0),0);
 let tax=taxFor(subtotal);
 let total=totalWithTax(subtotal);

 modalBody.innerHTML=
 `<h2>Your Pickup Order</h2>
 ${cart.length?
 cart.map((x,n)=>
 `<div class="cartrow">
 <div>
 <b>${menu[x.i][1]}</b>
 <small>${
 [x.tops?.join(", "),x.extra?"Add chili":null,x.notes]
 .filter(Boolean).join(" • ")
 }</small>
 </div>
 <span>${money(menu[x.i][3]+(x.extra||0))}
 <button class="remove" onclick="removeItem(${n})">×</button>
 </span>
 </div>`).join("")
 :"<p>Your order is empty.</p>"}

 <div class="total" style="padding-bottom:4px">Subtotal <b>${money(subtotal)}</b></div>
 <div class="total" style="padding-top:4px;padding-bottom:4px">NC sales tax (6.75%) <b>${money(tax)}</b></div>
 <div class="total" style="padding-top:8px">Total <b>${money(total)}</b></div>

 <label class="label">Your name</label>
 <input id="name" class="field" autocomplete="name" value="${String(lastCustomer.name||"").replace(/"/g,"&quot;")}">

 <label class="label">Phone number</label>
 <input id="phone" class="field" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" placeholder="828-555-1234" value="${String(lastCustomer.phone||"").replace(/"/g,"&quot;")}">

 <label class="label">Pickup time</label>
 <select id="time" class="field">${pickupOptions()}</select>

 <label class="label">Order notes</label>
 <textarea id="notes" class="field"></textarea>

 <div class="botCheck" style="margin:16px 0;padding:14px;border:2px solid #ddd;border-radius:10px">
  <label style="display:flex;gap:10px;align-items:center;font-weight:800">
   <input id="humanCheck" type="checkbox" style="width:22px;height:22px"> I’m a real person placing this order
  </label>
  <small style="display:block;margin-top:7px">Required before the order can be sent.</small>
 </div>
 <input id="websiteField" type="text" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-10000px;width:1px;height:1px;opacity:0">
 <button id="placeOrderBtn" class="checkout" onclick="placeOrder()">PLACE PICKUP ORDER</button>
 <p class="notice">Payment at pickup.</p>`;

 openModal();
}

function removeItem(n){
 cart.splice(n,1);
 save();
 openCart();
}

function openModal(){
 modal.classList.remove("hidden");
}

function closeModal(){
 modal.classList.add("hidden");
}

function backdrop(e){
 if(e.target.id==="modal")closeModal();
}

async function placeOrder(){
 const customerName=document.querySelector("#name")?.value.trim()||"";
 const customerPhone=document.querySelector("#phone")?.value.trim()||"";
 if(customerName||customerPhone){ lastCustomer={name:customerName,phone:customerPhone}; localStorage.setItem("bdCustomer",JSON.stringify(lastCustomer)); }
 try{
  const settings=await bdGetRestaurantSettings();
  orderingOpen=settings?.ordering_open!==false;
  orderingStatusKnown=true;
  if(!orderingOpen) return showOrderingPaused();
 }catch(e){
  return alert("We could not confirm that online ordering is open. Please try again.");
 }
 if(!cart.length)return alert("Add something first.");
 try{
  const rows=await bdGetMenuAvailability();
  const liveAvailability=Object.fromEntries((rows||[]).map(r=>[r.item_name,r.available!==false]));
  const soldOutInCart=cart.find(x=>liveAvailability[menu[x.i][1]]===false);
  if(soldOutInCart) return alert(`${menu[soldOutInCart.i][1]} is now sold out. Please remove it from your order.`);
 }catch(e){
  return alert("We could not confirm menu availability. Please try again.");
 }

 const nameEl=document.querySelector("#name");
 const phoneEl=document.querySelector("#phone");
 const timeEl=document.querySelector("#time");
 const notesEl=document.querySelector("#notes");
 const humanEl=document.querySelector("#humanCheck");
 const honeypot=document.querySelector("#websiteField");
 if(honeypot?.value) return alert("Order verification failed. Please refresh and try again.");
 if(!nameEl?.value.trim()||!phoneEl?.value.trim()||!timeEl?.value)
  return alert("Enter your name, phone number and pickup time.");
 const digits=phoneEl.value.replace(/\D/g,"");
 if(digits.length<10) return alert("Enter a valid phone number with area code.");
 if(!humanEl?.checked) return alert("Please confirm that you’re a real person before placing the order.");

 let subtotal=cart.reduce((s,x)=>s+menu[x.i][3]+(x.extra||0),0);
 let tax=taxFor(subtotal);
 let total=totalWithTax(subtotal);
 const submitBtn=document.querySelector("#placeOrderBtn");
 if(submitBtn?.disabled) return;
 if(submitBtn){ submitBtn.disabled=true; submitBtn.textContent="SENDING ORDER…"; }

 let order={
  customer_name:nameEl.value.trim(),
  phone:phoneEl.value.trim(),
  pickup_time:timeEl.value,
  notes:notesEl?.value.trim()||"",
  items:cart.map(x=>({
   name:menu[x.i][1],
   options:[
    x.tops?.join(", "),
    x.extra?"Add chili":null
   ].filter(Boolean).join(" • "),
   notes:x.notes||"",
   price:menu[x.i][3]+(x.extra||0)
  })),
  total,
  status:"New"
 };

 try{
  let saved=await bdCreateOrder(order);
  cart=[];
  save();

  modalBody.innerHTML=
  `<div class="orderSuccess"><div class="successCheck">✓</div><h2>Order Received!</h2>
  <p class="successLead">Your order is in the kitchen.</p><p><b>PAY AT PICKUP</b><br>No online payment was taken. Please pay at the restaurant when you pick up your order.</p>
  ${saved.id?`<div class="orderNumber">ORDER #${String(saved.id).slice(0,8).toUpperCase()}</div>`:""}</div>
  <p><b>Pickup:</b> ${timeEl.value}<br><b>Subtotal:</b> ${money(subtotal)}<br><b>NC sales tax (6.75%):</b> ${money(tax)}<br><b>Total:</b> ${money(total)}</p>
  <button class="checkout" onclick="closeModal()">DONE</button>`;
 }catch(e){
  if(submitBtn){ submitBtn.disabled=false; submitBtn.textContent="PLACE PICKUP ORDER"; }
  alert("Order could not be sent. Please try again.");
 }
}

applyBusinessBranding();
render();
update();
showStaffReturnIfLocked();
refreshOrderingStatus();
refreshMenuAvailability();
loadEditableMenu();
setInterval(refreshOrderingStatus,30000);
setInterval(refreshMenuAvailability,30000);
setInterval(loadEditableMenu,30000);
