
const BD_BRAND_DEFAULTS={businessName:"Baker's Dawgs",tagline:"Made fresh. Order ahead. Pick it up hot.",phone:"8282051139",email:"dawgsbaker@gmail.com",logo:"",background:"",primary:"#15100b",accent:"#ffc21a",specialEnabled:false,specialTitle:"",specialMessage:""};
function getBusinessBranding(){try{return {...BD_BRAND_DEFAULTS,...JSON.parse(localStorage.getItem("bdBusinessBranding")||"{}")};}catch(e){return {...BD_BRAND_DEFAULTS};}}
async function loadBusinessBrandingForm(){
 let b={...BD_BRAND_DEFAULTS};
 try{const cloud=await bdGetBusinessBranding();if(cloud)b={...b,businessName:cloud.business_name,tagline:cloud.tagline,phone:cloud.phone,email:cloud.email,logo:cloud.logo_url,background:cloud.background_url,primary:cloud.primary_color,accent:cloud.accent_color,specialEnabled:cloud.special_enabled,specialTitle:cloud.special_title,specialMessage:cloud.special_message};}catch(e){try{b={...b,...JSON.parse(localStorage.getItem("bdBusinessBranding")||"{}")};}catch(_){}}
 localStorage.setItem("bdBusinessBranding",JSON.stringify(b));
 const map={brandBusinessName:"businessName",brandTagline:"tagline",brandPhone:"phone",brandEmail:"email",brandLogo:"logo",brandBackground:"background",brandPrimary:"primary",brandAccent:"accent",brandSpecialTitle:"specialTitle",brandSpecialMessage:"specialMessage"};
 Object.entries(map).forEach(([id,key])=>{const el=document.getElementById(id);if(el)el.value=b[key]||"";});
 const special=document.getElementById("brandSpecialEnabled");if(special)special.checked=b.specialEnabled===true;
 updateBrandPreview();updateSetupChecklist();
}
async function saveBusinessBranding(){
 const val=id=>(document.getElementById(id)?.value||"").trim();
 const b={businessName:val("brandBusinessName")||BD_BRAND_DEFAULTS.businessName,tagline:val("brandTagline")||BD_BRAND_DEFAULTS.tagline,phone:val("brandPhone"),email:val("brandEmail"),logo:val("brandLogo"),background:val("brandBackground"),primary:document.getElementById("brandPrimary")?.value||BD_BRAND_DEFAULTS.primary,accent:document.getElementById("brandAccent")?.value||BD_BRAND_DEFAULTS.accent,specialEnabled:!!document.getElementById("brandSpecialEnabled")?.checked,specialTitle:val("brandSpecialTitle"),specialMessage:val("brandSpecialMessage")};
 const s=document.getElementById("brandingStatus");if(s)s.textContent="Saving branding to all devices…";
 try{await bdSaveBusinessBranding(b);localStorage.setItem("bdBusinessBranding",JSON.stringify(b));if(s)s.textContent="Saved — customer website/app will use these settings.";alert("Business branding saved for all devices.");return true;}catch(e){console.error(e);if(s)s.textContent="Could not save branding to the cloud.";alert("Could not save branding. Make sure you are signed in as staff.");return false;}
}
async function previewBusinessBranding(){if(await saveBusinessBranding())window.open("index.html?brand_preview=1","_blank");}
async function resetBusinessBranding(){if(!confirm("Reset business branding to the installed defaults?"))return;const map={brandBusinessName:"businessName",brandTagline:"tagline",brandPhone:"phone",brandEmail:"email",brandLogo:"logo",brandBackground:"background",brandPrimary:"primary",brandAccent:"accent",brandSpecialTitle:"specialTitle",brandSpecialMessage:"specialMessage"};Object.entries(map).forEach(([id,key])=>{const el=document.getElementById(id);if(el)el.value=BD_BRAND_DEFAULTS[key]||"";});const special=document.getElementById("brandSpecialEnabled");if(special)special.checked=false;updateBrandPreview();await saveBusinessBranding();}

function upgradeCustomizationUI(){
 const branding=document.querySelector(".ownerBranding");
 if(branding&&!branding.dataset.upgraded){
  branding.dataset.upgraded="1";
  branding.innerHTML=`<div class="sectionTitle"><div><span class="eyebrow">OWNER SETTINGS</span><b>Customize your business</b><small>Give this template its own name, colors, and artwork. No source code needed.</small></div><div class="brandPreview" id="brandPreview"><span>LIVE LOOK</span><strong id="brandPreviewName">Baker's Dawgs</strong></div></div><div class="brandingFields"><label>Business name<input id="brandBusinessName" type="text" placeholder="Your Restaurant" oninput="updateBrandPreview()"></label><label>Tagline<input id="brandTagline" type="text" placeholder="Order ahead. Pick it up hot."></label><label>Phone<input id="brandPhone" type="tel" placeholder="555-555-5555"></label><label>Email<input id="brandEmail" type="email" placeholder="orders@example.com"></label><label>Primary color<input id="brandPrimary" type="color" value="#15100b" oninput="updateBrandPreview()"></label><label>Accent color<input id="brandAccent" type="color" value="#ffc21a" oninput="updateBrandPreview()"></label></div><div class="artworkUpload"><div><b>Logo artwork</b><small>Upload a logo from this phone or tablet, or paste an image link.</small><input id="brandLogo" type="url" placeholder="Paste logo image link"><input id="brandLogoUpload" type="file" accept="image/*"></div><button type="button" class="secondaryButton" onclick="document.getElementById('brandLogoUpload').click()">UPLOAD LOGO</button></div><div class="artworkUpload"><div><b>Full background artwork</b><small>Use a food photo, texture, or your own branded background.</small><input id="brandBackground" type="url" placeholder="Paste background image link"><input id="brandBackgroundUpload" type="file" accept="image/*"></div><button type="button" class="secondaryButton" onclick="document.getElementById('brandBackgroundUpload').click()">UPLOAD BACKGROUND</button></div><div class="buttonRow"><button type="button" onclick="saveBusinessBranding()">SAVE BRAND LOOK</button><button type="button" class="secondaryButton" onclick="previewBusinessBranding()">PREVIEW CUSTOMER SCREEN</button><button type="button" class="textButton" onclick="resetBusinessBranding()">RESET</button></div><small id="brandingStatus">Changes save to the restaurant template.</small>`;
  branding.insertAdjacentHTML("afterbegin",`<div class="setupChecklist"><div><span class="eyebrow">SETUP CHECKLIST</span><b>Ready to launch?</b></div><div id="setupSteps" class="setupSteps"></div></div>`);
  document.getElementById("brandPreview")?.insertAdjacentHTML("afterend",`<div class="previewSwitch"><span>Preview</span><button type="button" class="active" onclick="setPreviewMode('phone',this)">PHONE</button><button type="button" onclick="setPreviewMode('tablet',this)">TABLET</button></div>`);
  branding.querySelector(".buttonRow")?.insertAdjacentHTML("beforebegin",`<div class="specialEditor"><span class="eyebrow">OPTIONAL DAILY SPECIAL</span><label class="specialToggle"><input id="brandSpecialEnabled" type="checkbox"> Show a special on the customer menu</label><label>Special headline<input id="brandSpecialTitle" type="text" maxlength="45" placeholder="Today’s Special"></label><label>Special message<input id="brandSpecialMessage" type="text" maxlength="120" placeholder="Example: Free cake slice with a meal today."></label></div>`);
  document.getElementById("brandLogoUpload")?.addEventListener("change",e=>uploadBrandImage(e.target,"brandLogo"));
  document.getElementById("brandBackgroundUpload")?.addEventListener("change",e=>uploadBrandImage(e.target,"brandBackground"));
 }
 const manager=document.querySelector("#menuAvailabilityControls")?.closest(".menuControls");
 if(manager&&!manager.dataset.upgraded){
  manager.dataset.upgraded="1";
  manager.classList.add("menuManager");
  manager.querySelector("div")?.replaceWith(Object.assign(document.createElement("div"),{className:"sectionTitle",innerHTML:`<div><span class="eyebrow">MENU BUILDER</span><b>Menu items</b><small>Edit prices and descriptions, add an item, or remove one before handing this template to the next owner.</small></div><button type="button" onclick="openMenuItemEditor()">＋ ADD MENU ITEM</button>`}));
  manager.insertAdjacentHTML("beforeend",`<div id="menuBuilderFooter" class="menuBuilderFooter"><button type="button" class="secondaryButton" onclick="restoreSampleMenu()">RESTORE SAMPLE MENU</button><small>Menu changes save immediately and update the customer screen.</small></div>`);
  manager.querySelector(".sectionTitle")?.insertAdjacentHTML("afterend",`<div id="menuFilterTabs" class="menuFilterTabs"></div>`);
 }
}
function updateBrandPreview(){const name=document.getElementById("brandBusinessName")?.value||"Your Restaurant";const primary=document.getElementById("brandPrimary")?.value||"#15100b";const accent=document.getElementById("brandAccent")?.value||"#ffc21a";const p=document.getElementById("brandPreview"),t=document.getElementById("brandPreviewName");if(p){p.style.background=primary;p.style.borderColor=accent;}if(t){t.textContent=name;t.style.color=accent;}}
function setPreviewMode(mode,button){previewMode=mode;document.querySelector(".brandPreview")?.classList.toggle("tabletPreview",mode==="tablet");document.querySelectorAll(".previewSwitch button").forEach(b=>b.classList.toggle("active",b===button));}
function updateSetupChecklist(){const box=document.getElementById("setupSteps");if(!box)return;const checks=[["Business details",!!document.getElementById("brandBusinessName")?.value&&!!document.getElementById("brandPhone")?.value],["Brand colors",!!document.getElementById("brandPrimary")?.value&&!!document.getElementById("brandAccent")?.value],["Artwork",!!document.getElementById("brandLogo")?.value||!!document.getElementById("brandBackground")?.value],["Menu",editableMenuItems.length>0]];box.innerHTML=checks.map(([label,done])=>`<span class="${done?"done":""}">${done?"✓":"○"} ${label}</span>`).join("");}
async function uploadBrandImage(input,targetId){
 const file=input?.files?.[0];if(!file)return;
 if(!file.type.startsWith("image/")){alert("Please choose an image file.");return;}
 const status=document.getElementById("brandingStatus");if(status)status.textContent="Preparing artwork…";
 const source=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});
 const img=await new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=reject;i.src=source;});
 const max=1600,scale=Math.min(1,max/Math.max(img.width,img.height));const canvas=document.createElement("canvas");canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));canvas.getContext("2d").drawImage(img,0,0,canvas.width,canvas.height);
 const data=canvas.toDataURL("image/jpeg",.88);if(data.length>1800000){alert("That image is still too large. Please choose a smaller photo.");return;}
 const field=document.getElementById(targetId);if(field)field.value=data;if(status)status.textContent="Artwork ready — press Save Brand Look to publish it.";
}

const statuses=["New","Accepted","Cooking","Ready","Completed"];
let currentFilter="all";
let hideCompleted=true;
let knownOrderIds=new Set();
let firstOrderLoad=true;
let orderingOpen=null;
let prepMinutes=20;
let menuAvailability={};
let soundEnabled=localStorage.getItem("bdSoundEnabled")!=="false";
const adminMenuItems=["Carolina Classic Hot Dawg","Sauerkraut & Mustard Dawg","Chili & Cheez Dawg","Chili, Onion & Mustard Dawg","Sweet Relish & Mustard Dawg","Loaded Hot Dawg","Brat / Bratwurst","Classic Plain Smoked Sausage","Cheddar Cheez Smoked Sausage","Jalapeño Smoked Sausage","The Perfect Brat","Grilled Bologna on Toast (cut #5)","Grilled Cheez Quesadilla","Bottled Drink / Soda","Bottled Water","Sweet Tea with Ice","Lemonade Sweet Tea with Ice","Chips","German Chocolate Cake","3 Milks Cake"];
let editableMenuItems=[];
let currentMenuCategory="All";
let previewMode="phone";

function esc(v=""){
 return String(v).replace(/[&<>"']/g,c=>({
  "&":"&amp;","<":"&lt;",">":"&gt;",
  '"':"&quot;","'":"&#39;"
 }[c]));
}

function updateClock(){
 const el=document.querySelector("#clock");
 if(el) el.textContent=new Date().toLocaleString([], {weekday:"short",hour:"numeric",minute:"2-digit"});
}

function isLate(o){
 if(o.status==="Completed"||!o.pickup_time) return false;
 const [h,m]=String(o.pickup_time).split(":").map(Number);
 if(Number.isNaN(h)||Number.isNaN(m)) return false;
 const due=new Date(o.created_at); due.setHours(h,m,0,0);
 return Date.now()>due.getTime();
}

function nextStatus(status){
 const i=statuses.indexOf(status);
 return i>=0&&i<statuses.length-1?statuses[i+1]:null;
}

function statusActionLabel(status){
 return ({New:"ACCEPT ORDER",Accepted:"START COOKING",Cooking:"MARK READY",Ready:"COMPLETE ORDER"})[status]||"";
}

function waitTime(created){
 const mins=Math.max(0,Math.floor((Date.now()-new Date(created).getTime())/60000));
 return mins<1?"just now":mins===1?"1 min ago":`${mins} mins ago`;
}

function toggleSound(){
 soundEnabled=!soundEnabled;
 localStorage.setItem("bdSoundEnabled",String(soundEnabled));
 const btn=document.querySelector("#soundToggle");
 if(btn) btn.textContent=soundEnabled?"🔔 Alerts On":"🔕 Alerts Off";
 if(soundEnabled) playOrderAlert();
}

function playOrderAlert(){
 if(!soundEnabled) return;
 try{
  const ctx=new (window.AudioContext||window.webkitAudioContext)();
  const master=ctx.createGain();
  master.gain.value=.45;
  master.connect(ctx.destination);
  const ring=(frequency,start,duration)=>{
   const osc=ctx.createOscillator(),gain=ctx.createGain();
   osc.type="sine"; osc.frequency.value=frequency;
   gain.gain.setValueAtTime(0,ctx.currentTime+start);
   gain.gain.linearRampToValueAtTime(.8,ctx.currentTime+start+.02);
   gain.gain.setValueAtTime(.8,ctx.currentTime+start+duration-.04);
   gain.gain.linearRampToValueAtTime(0,ctx.currentTime+start+duration);
   osc.connect(gain); gain.connect(master);
   osc.start(ctx.currentTime+start); osc.stop(ctx.currentTime+start+duration+.02);
  };
  ring(659,0,.18); ring(784,.20,.18); ring(988,.40,.28);
  setTimeout(()=>ctx.close(),1000);
 }catch(e){}
 if(navigator.vibrate) navigator.vibrate([180,80,260]);
}


// Fingerprint unlock opens a saved staff session; first sign-in still requires a password.
async function onNativeBiometricSuccess(purpose){
 if(purpose==="enroll"){
  try{
   const user=await bdCurrentStaffUser();
   localStorage.setItem("bdNativeBiometricUserId",user.id);
   alert("Fingerprint unlock is enabled for this staff account on this device. Your staff PIN still works.");
  }catch(e){alert("Could not link fingerprint to your staff account. Sign in again and retry.");}
  return;
 }
 if(!localStorage.getItem("bdNativeBiometricUserId")){alert("Sign in and enable fingerprint unlock for this staff account first.");return;}
 try{
  if(!await bdRefreshSession())throw new Error("Staff session expired. Sign in with your password again.");
  const user=await bdCurrentStaffUser();
  if(user.id!==localStorage.getItem("bdNativeBiometricUserId"))throw new Error("This fingerprint unlock belongs to a different staff account. Sign in with your own password.");
  document.querySelector("#pinGate")?.classList.add("hidden");
  showBoard();
 }catch(e){alert(e.message||"Please sign in with your staff password.");location.reload();}
}
function onNativeBiometricError(message){alert("Fingerprint unavailable: "+message+" You can use your staff PIN.");}
async function enrollBiometric(){
 if(!bdHasSavedSession()){alert("Sign in with your own staff email and password first.");return;}
 if(window.BakersDawgsAndroid?.authenticateBiometric){
  try{if(!await bdRefreshSession())throw new Error("Session expired");await bdCurrentStaffUser();}
  catch(e){alert("Your staff session expired. Sign in again.");return;}
  window.BakersDawgsAndroid.authenticateBiometric("enroll");return;
 }
 if(!window.PublicKeyCredential){alert("This browser does not support passkeys.");return;}
 try{
  if(!await bdRefreshSession())throw new Error("Staff session expired");
  await bdRegisterPasskey();
  localStorage.setItem("bdWebPasskeyEnrolled","1");
  alert("Passkey registered. You can use it to sign in from this browser.");
 }catch(e){alert("Could not register the passkey: "+(e?.message||"Please try again."));}
}
async function biometricUnlock(){
 if(window.BakersDawgsAndroid?.authenticateBiometric){
  if(!bdHasSavedSession()){alert("Sign in with your staff email and password once on this phone, then add its fingerprint.");return;}
  if(!localStorage.getItem("bdNativeBiometricUserId")){alert("Sign in and tap 'Enable fingerprint for this account' first. You can use your staff PIN now.");return;}
  window.BakersDawgsAndroid.authenticateBiometric("unlock");return;
 }
 if(!window.PublicKeyCredential){alert("This browser does not support passkeys.");return;}
 try{
  const data=await bdSignInWithPasskey();
  if(!data?.session)throw new Error("No authenticated session was returned.");
  sessionStorage.removeItem("bdReturnToAdmin");showBoard();
 }catch(e){if(e?.name!=="NotAllowedError")alert("Passkey sign-in failed: "+(e?.message||"Please try again."));}
}

async function login(){
 const email=document.querySelector("#email").value.trim();
 const password=document.querySelector("#password").value;
 if(!email||!password){ alert("Enter staff email and password."); return; }
 console.log("Admin sign-in tapped", email);
 try{
  await bdSignIn(email,password);
  showBoard();
  const staffUser=await bdCurrentStaffUser();
  if((window.BakersDawgsAndroid?.authenticateBiometric && localStorage.getItem("bdNativeBiometricUserId")!==staffUser.id) || (!window.BakersDawgsAndroid && window.PublicKeyCredential && !localStorage.getItem("bdWebPasskeyEnrolled"))){
   setTimeout(()=>{ if(confirm("Add this device fingerprint/passkey so you can sign in after a restart?")) enrollBiometric(); },300);
  }
 }catch(e){ alert("Sign-in failed. Check the staff email and password."); }
}

async function forgotPassword(){
 const email=document.querySelector("#email").value.trim();
 if(!email){ alert("Enter the staff email address first."); return; }
 console.log("Password reset tapped", email);
 try{ await bdResetPassword(email); alert("Password reset email sent. Check the staff email inbox and follow the reset link."); }
 catch(e){ console.error("Password reset failed",e); alert("Password reset failed: "+(e?.message||"Please try again.")); }
}

function logout(){
 bdSignOut();
 location.reload();
}
function switchEmployee(){
 if(!confirm("Sign out this staff account so another employee can sign in?"))return;
 bdSignOut();
 location.reload();
}

let adminLockTimer=null;
const ADMIN_AUTO_LOCK_MS=5*60*1000;
const DEFAULT_STAFF_PIN_HASH="f3e055913a0b1eb0f07317896f9a1bc466b9a50db85a7f882f3ffde9ffb23aca";
let pinFailures=0, pinBlockedUntil=0;
async function hashPin(pin){
 const bytes=new TextEncoder().encode(pin);
 const digest=await crypto.subtle.digest("SHA-256",bytes);
 return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,"0")).join("");
}
async function unlockWithPin(){
 const input=document.querySelector("#staffPin"), msg=document.querySelector("#pinMessage");
 if(Date.now()<pinBlockedUntil){if(msg)msg.textContent="Too many attempts. Try again in a moment.";return;}
 const expected=localStorage.getItem("bdStaffPinHash")||DEFAULT_STAFF_PIN_HASH;
 if(await hashPin((input?.value||"").trim())===expected){
  pinFailures=0;if(input)input.value="";document.querySelector("#pinGate")?.classList.add("hidden");showBoard();return;
 }
 pinFailures++;if(input)input.value="";
 if(pinFailures>=5){pinBlockedUntil=Date.now()+30000;pinFailures=0;}
 if(msg)msg.textContent=pinBlockedUntil>Date.now()?"Too many attempts. Locked for 30 seconds.":"Incorrect PIN. Try again.";
}
function showPinGate(){
 const login=document.querySelector("#login"),recovery=document.querySelector("#recovery"),board=document.querySelector("#app"),gate=document.querySelector("#pinGate");
 if(login)login.style.display="none";if(recovery)recovery.style.display="none";
 if(board){board.classList.add("hidden");board.style.display="none";}
 if(gate){gate.classList.remove("hidden");gate.style.display="grid";}
 setTimeout(()=>document.querySelector("#staffPin")?.focus(),50);
}

function armAdminAutoLock(){
 clearTimeout(adminLockTimer);
 if(document.querySelector("#app")?.classList.contains("hidden")) return;
 adminLockTimer=setTimeout(lockAdminScreen,ADMIN_AUTO_LOCK_MS);
}
function lockAdminScreen(){
 clearTimeout(adminLockTimer);
 document.body.dataset.adminLocked="true";
 if(bdHasSavedSession()){showPinGate();return;}
 location.reload();
}
["pointerdown","keydown","touchstart","scroll"].forEach(evt=>{
 document.addEventListener(evt,()=>{
  if(document.body.dataset.adminLocked!=="true") armAdminAutoLock();
 },{passive:true});
});
document.addEventListener("visibilitychange",()=>{
 if(document.hidden && !document.querySelector("#app")?.classList.contains("hidden")) lockAdminScreen();
});

function showBoard(){
 const loginBox=document.querySelector("#login");
 const recoveryBox=document.querySelector("#recovery");
 const board=document.querySelector("#app");

 if(loginBox) loginBox.style.display="none";
 if(recoveryBox) recoveryBox.style.display="none";
 if(board){ board.classList.remove("hidden"); board.style.display="block"; }
 document.body.dataset.adminLocked="false";
 armAdminAutoLock();
 const soundBtn=document.querySelector("#soundToggle");
 if(soundBtn) soundBtn.textContent=soundEnabled?"🔔 Alerts On":"🔕 Alerts Off";

 loadOrders();
 loadRestaurantControls();
 upgradeCustomizationUI();
 loadMenuAvailability();
 loadBusinessBrandingForm();
}

async function loadRestaurantControls(){
 try{
  const settings=await bdGetRestaurantSettings();
  orderingOpen=settings?.ordering_open!==false;
  prepMinutes=Number(settings?.prep_minutes)||20;
  const prep=document.querySelector("#prepMinutes"); if(prep) prep.value=String(prepMinutes);
  const status=document.querySelector("#orderingStatus");
  const btn=document.querySelector("#orderingToggle");
  if(status) status.textContent=orderingOpen?"Customers can place pickup orders":"Ordering is paused";
  if(btn){ btn.disabled=false; btn.textContent=orderingOpen?"PAUSE ORDERS":"OPEN ORDERS"; btn.classList.toggle("closed",!orderingOpen); }
 }catch(e){
  const status=document.querySelector("#orderingStatus");
  if(status) status.textContent="Controls unavailable";
 }
}

async function loadMenuAvailability(){
 try{
  let items=[];
  try{items=await bdGetMenuItems();}catch(_){items=[];}
  if(items.length){editableMenuItems=items;if(!localStorage.getItem("bdSampleMenuTemplate"))localStorage.setItem("bdSampleMenuTemplate",JSON.stringify(items));}
  const rows=items.length?items:await bdGetMenuAvailability();
  menuAvailability=Object.fromEntries((rows||[]).map(r=>[r.item_name,r.available!==false]));
  const box=document.querySelector("#menuAvailabilityControls");
  const displayItems=editableMenuItems.length?editableMenuItems:adminMenuItems.map((name,index)=>({id:"legacy-"+index,item_name:name,category:"Current menu",description:"",price:"",available:menuAvailability[name]!==false,sort_order:index}));
  const tabs=document.getElementById("menuFilterTabs");const categories=["All",...new Set(displayItems.map(x=>x.category||"Menu item"))];if(!categories.includes(currentMenuCategory))currentMenuCategory="All";
  if(tabs)tabs.innerHTML=categories.map(category=>`<button type="button" class="${category===currentMenuCategory?"active":""}" onclick="setMenuCategory(decodeURIComponent(\'${encodeURIComponent(category)}\'))">${esc(category)}</button>`).join("");
  const visibleItems=displayItems.filter(item=>currentMenuCategory==="All"||item.category===currentMenuCategory);
  if(box) box.innerHTML=visibleItems.map(item=>{
   const available=item.available!==false&&menuAvailability[item.item_name]!==false;
   const price=Number.isFinite(Number(item.price))&&item.price!==""?`$${Number(item.price).toFixed(2)}`:"";
   return `<article class="menuAdminItem ${available?"available":"soldout"}"><div><span class="menuCategory">${esc(item.category||"Menu item")}</span><strong>${esc(item.item_name)}</strong>${item.description?`<small>${esc(item.description)}</small>`:""}</div><div class="menuItemActions"><b>${price}</b><button type="button" class="availabilityButton" onclick="toggleMenuItem(decodeURIComponent(\'${encodeURIComponent(item.item_name)}\'))">${available?"AVAILABLE":"SOLD OUT"}</button><button type="button" class="editItemButton" onclick="openMenuItemEditor(decodeURIComponent(\'${encodeURIComponent(item.id)}\'))">EDIT</button><button type="button" class="editItemButton" onclick="duplicateMenuItem(decodeURIComponent(\'${encodeURIComponent(item.id)}\'))">DUPLICATE</button><button type="button" class="editItemButton" onclick="moveMenuItem(decodeURIComponent(\'${encodeURIComponent(item.id)}\'),-1)">↑</button><button type="button" class="editItemButton" onclick="moveMenuItem(decodeURIComponent(\'${encodeURIComponent(item.id)}\'),1)">↓</button><button type="button" class="deleteItemButton" onclick="removeMenuItem(decodeURIComponent(\'${encodeURIComponent(item.id)}\'))">DELETE</button></div></article>`;
   }).join("");
  updateSetupChecklist();
 }catch(e){
  const box=document.querySelector("#menuAvailabilityControls");
  if(box) box.textContent="Menu controls unavailable.";
 }
}
function setMenuCategory(category){currentMenuCategory=category;loadMenuAvailability();}
async function duplicateMenuItem(id){const item=editableMenuItems.find(x=>x.id===id);if(!item)return;const duplicate={...item,id:"item-"+Date.now(),item_name:item.item_name+" Copy",sort_order:Number(item.sort_order||0)+.5};try{await bdSaveMenuItem(duplicate);await loadMenuAvailability();}catch(e){alert("Could not duplicate that menu item.");}}
async function moveMenuItem(id,direction){const current=editableMenuItems.find(x=>x.id===id);if(!current)return;const same=editableMenuItems.filter(x=>x.category===current.category).sort((a,b)=>(a.sort_order||0)-(b.sort_order||0));const index=same.findIndex(x=>x.id===id),swap=same[index+direction];if(!swap)return;const old=current.sort_order;current.sort_order=swap.sort_order;swap.sort_order=old;try{await bdSaveMenuItem(current);await bdSaveMenuItem(swap);await loadMenuAvailability();}catch(e){alert("Could not move that menu item.");}}
async function restoreSampleMenu(){
 const saved=localStorage.getItem("bdSampleMenuTemplate");if(!saved){alert("Open the upgraded menu once before using Restore Sample Menu.");return;}
 if(!confirm("Restore the original sample menu? This removes menu changes made after the template was first opened on this device."))return;
 try{for(const item of editableMenuItems)await bdDeleteMenuItem(item.id);for(const item of JSON.parse(saved))await bdSaveMenuItem(item);await loadMenuAvailability();alert("Sample menu restored.");}catch(e){alert("Could not restore the sample menu.");}
}

function openMenuItemEditor(id=""){
 const existing=editableMenuItems.find(x=>x.id===id)||{};
 if(id&&id.startsWith("legacy-")){alert("The one-time menu upgrade has not been installed yet. Once it is installed, every item can be edited and removed here.");return;}
 const dialog=document.createElement("div");dialog.className="menuEditorModal";
 dialog.innerHTML=`<section><button class="closeEditor" aria-label="Close">×</button><span class="eyebrow">MENU BUILDER</span><h2>${id?"Edit menu item":"Add menu item"}</h2><label>Category<input id="editorCategory" value="${esc(existing.category||"Hot Dawgs")}" placeholder="Hot Dawgs"></label><label>Item name<input id="editorName" value="${esc(existing.item_name||"")}" placeholder="Item name"></label><label>Description<textarea id="editorDescription" placeholder="Short description">${esc(existing.description||"")}</textarea></label><label>Price<input id="editorPrice" value="${existing.price??""}" inputmode="decimal" placeholder="0.00"></label><label class="availabilityCheck"><input id="editorAvailable" type="checkbox" ${existing.available!==false?"checked":""}> Available to order</label><div class="editorButtons"><button type="button" class="secondaryButton closeEditor">CANCEL</button><button type="button" id="saveMenuItemButton">SAVE MENU ITEM</button></div></section>`;
 document.body.append(dialog);
 const close=()=>dialog.remove();dialog.querySelectorAll(".closeEditor").forEach(b=>b.addEventListener("click",close));
 dialog.addEventListener("click",e=>{if(e.target===dialog)close();});
 dialog.querySelector("#saveMenuItemButton").addEventListener("click",async()=>{
  const category=dialog.querySelector("#editorCategory").value.trim(),item_name=dialog.querySelector("#editorName").value.trim(),description=dialog.querySelector("#editorDescription").value.trim(),price=Number(dialog.querySelector("#editorPrice").value);
  if(!category||!item_name||!Number.isFinite(price)||price<0){alert("Enter a category, item name, and valid price.");return;}
  const item={id:id||("item-"+Date.now()),category,item_name,description,price,available:dialog.querySelector("#editorAvailable").checked,sort_order:existing.sort_order??editableMenuItems.length};
  try{await bdSaveMenuItem(item);close();await loadMenuAvailability();}catch(e){alert("Could not save the menu item. Run the menu upgrade once in Supabase, then try again.");}
 });
}
async function removeMenuItem(id){
 if(!id||id.startsWith("legacy-")){alert("The one-time menu upgrade has not been installed yet.");return;}
 const item=editableMenuItems.find(x=>x.id===id);if(!item||!confirm(`Remove ${item.item_name} from the menu?`))return;
 try{await bdDeleteMenuItem(id);await loadMenuAvailability();}catch(e){alert("Could not remove that menu item.");}
}

async function toggleMenuItem(name){
 const available=menuAvailability[name]!==false;
 try{
  await bdSetMenuAvailability(name,!available);
  await loadMenuAvailability();
 }catch(e){ alert("Could not update that menu item."); }
}

async function changePrepMinutes(value){
 const minutes=Number(value);
 if(![15,20,30,45,60].includes(minutes)) return;
 try{ await bdSetPrepMinutes(minutes); prepMinutes=minutes; }
 catch(e){ alert("Could not update pickup lead time."); await loadRestaurantControls(); }
}

async function toggleOrdering(){
 if(orderingOpen===null) return;
 const btn=document.querySelector("#orderingToggle");
 if(btn) btn.disabled=true;
 try{
  await bdSetOrderingOpen(!orderingOpen);
  await loadRestaurantControls();
 }catch(e){
  if(btn) btn.disabled=false;
  alert("Could not change online ordering. Check that restaurant controls are installed in Supabase.");
 }
}

async function loadOrders(){
 const list=document.querySelector("#orders");

 try{
  const orders=await bdGetOrders();
  window.bdCurrentOrders=orders;
  const newIds=orders.filter(o=>o.status==="New"&&!knownOrderIds.has(o.id)).map(o=>o.id);
  if(!firstOrderLoad&&newIds.length){ playOrderAlert(); }
  knownOrderIds=new Set(orders.map(o=>o.id));
  firstOrderLoad=false;

  const today=new Date().toDateString();
  const todays=orders.filter(o=>new Date(o.created_at).toDateString()===today);
  const sales=todays.filter(o=>o.status==="Completed").reduce((s,o)=>s+Number(o.total||0),0);
  const completed=todays.filter(o=>o.status==="Completed").length;
  const salesEl=document.querySelector("#salesToday"),ordersEl=document.querySelector("#ordersToday"),avgEl=document.querySelector("#avgTicket");
  if(salesEl) salesEl.textContent=`${sales.toFixed(2)}`;
  if(ordersEl) ordersEl.textContent=todays.length;
  if(avgEl) avgEl.textContent=completed?`${(sales/completed).toFixed(2)}`:"$0.00";

  const newCount=document.querySelector("#newCount");
  const readyCount=document.querySelector("#readyCount");
  if(newCount) newCount.textContent=orders.filter(o=>o.status==="New").length;
  if(readyCount) readyCount.textContent=orders.filter(o=>o.status==="Ready").length;

  const count=document.querySelector("#openCount");
  if(count){
   count.textContent=orders.filter(o=>o.status!=="Completed").length;
  }

  if(!orders.length){
   list.innerHTML="<p>No orders yet.</p>";
   return;
  }

  const visibleOrders=(currentFilter==="all"?orders:orders.filter(o=>o.status===currentFilter))
    .filter(o=>!hideCompleted||o.status!=="Completed");

  list.innerHTML=visibleOrders.map(o=>`
   <article class="order ${o.status==="New"?"new":""} ${isLate(o)?"late":""}">
    <div class="orderTop">
     <div>
      <h2>${esc(o.customer_name)}</h2>
      <div><a class="phoneLink" href="tel:${esc(String(o.phone||'').replace(/[^+\d]/g,''))}">${esc(o.phone)}</a> • Pickup: ${esc(o.pickup_time)} • ${waitTime(o.created_at)}</div>
     </div>
     <strong>$${Number(o.total).toFixed(2)}</strong>
    </div>

    <div class="status status-${esc(o.status)}">
     ${esc(o.status)}
    </div>

    <div class="items">
     ${(o.items||[]).map(i=>`
      <div class="orderItem">
       <b>${esc(i.name)}</b>
       ${i.options?`<small>${esc(i.options)}</small>`:""}
       ${i.notes?`<small>Note: ${esc(i.notes)}</small>`:""}
       <span>$${Number(i.price||0).toFixed(2)}</span>
      </div>
     `).join("")}
    </div>

    ${o.notes?`<p><b>Order note:</b> ${esc(o.notes)}</p>`:""}

    <div class="speechActions"><button type="button" onclick="speakKitchenOrder(\'${o.id}\')">🔊 READ ORDER</button>${(o.items||[]).map((i,n)=>`<button type="button" onclick="speakKitchenOrder(\'${o.id}\',${n})">Read Item ${n+1}</button>`).join("")}</div>

    ${typeof bdPaymentSelector==="function"?bdPaymentSelector(o):""}\n    ${nextStatus(o.status)?`<button class="nextStatus" onclick="changeStatus('${o.id}','${nextStatus(o.status)}')">${statusActionLabel(o.status)}</button>`:""}

    <select onchange="changeStatus('${o.id}',this.value)">
     ${statuses.map(s=>
      `<option value="${s}" ${o.status===s?"selected":""}>${s}</option>`
     ).join("")}
    </select>

    <button onclick="deleteOrder('${o.id}')">Delete Order</button>
   </article>
  `).join("");

 }catch(e){
  if(e.status===401||e.status===403){
   bdSignOut();
   alert("Your staff session expired. Please sign in again.");
   location.reload();
   return;
  }
  list.innerHTML="<p>Could not load orders. Check the connection.</p>";
 }
}


let lastSpokenOrderId=null;
function orderSpeechText(o, itemIndex=null){
 const items=Array.isArray(o.items)?o.items:[];
 const chosen=itemIndex===null?items:(items[itemIndex]?[items[itemIndex]]:[]);
 const lines=chosen.map((i,n)=>{
  const label=itemIndex===null?`Item ${n+1}`:`Item ${itemIndex+1}`;
  return [label, i.name, i.options?`with ${i.options}`:"", i.notes?`Note: ${i.notes}`:""].filter(Boolean).join(". ");
 });
 return [itemIndex===null?`Order for ${o.customer_name||"customer"}.`:"", ...lines, itemIndex===null&&o.notes?`Order note: ${o.notes}`:""].filter(Boolean).join(". ");
}
function bestKitchenVoice(){
 const voices=speechSynthesis.getVoices();
 const english=voices.filter(v=>/^en(-|_)/i.test(v.lang||""));
 const naturalHints=/natural|neural|enhanced|premium|google|samsung|microsoft|siri/i;
 return english.find(v=>naturalHints.test(v.name||""))||english.find(v=>/en-US/i.test(v.lang||""))||english[0]||voices[0]||null;
}
function speakKitchenOrder(id,itemIndex=null){
 const o=(window.bdCurrentOrders||[]).find(x=>String(x.id)===String(id));
 if(!o){alert("Order is no longer on the board.");return;}
 const text=orderSpeechText(o,itemIndex);
 if(window.BakersDawgsAndroid&&typeof window.BakersDawgsAndroid.speak==="function"){
  window.BakersDawgsAndroid.speak(text);
  lastSpokenOrderId=o.id;
  return;
 }
 if(!("speechSynthesis" in window)){alert("This device does not support spoken order read-back.");return;}
 speechSynthesis.cancel();
 const u=new SpeechSynthesisUtterance(text);
 const voice=bestKitchenVoice(); if(voice){u.voice=voice;u.lang=voice.lang||"en-US";}
 u.rate=.88; u.pitch=1; u.volume=1;
 speechSynthesis.speak(u);
 lastSpokenOrderId=o.id;
}
function repeatLastOrder(){
 if(!lastSpokenOrderId){alert("Tap Read Order on an order first.");return;}
 speakKitchenOrder(lastSpokenOrderId);
}
function stopOrderSpeech(){ if(window.BakersDawgsAndroid&&typeof window.BakersDawgsAndroid.stopSpeaking==="function") window.BakersDawgsAndroid.stopSpeaking(); if("speechSynthesis" in window) speechSynthesis.cancel(); }
let kitchenRecognition=null,kitchenListening=false,kitchenPauseTimer=null,kitchenStarting=false,kitchenRecognizing=false;
function voiceStatus(msg){const el=document.querySelector("#voiceAssistantStatus");if(el)el.textContent=msg;}
function onNativeVoiceStatus(msg){voiceStatus(msg);}
function onNativeVoiceError(msg){kitchenListening=false;voiceStatus(msg);}
function onNativeVoiceCommand(transcript){handleKitchenCommand(transcript);}
function handleKitchenCommand(transcript){
 const said=String(transcript||"").toLowerCase().trim();
 if(/stop listening|pause baker|baker pause|pause assistant/.test(said)){stopKitchenListening("Voice assistant paused.");return;}
 if(/(?:pause|stop) (?:for )?(10|ten|30|thirty) minutes?/.test(said)){
  pauseKitchenListening(/30|thirty/.test(said)?30:10);return;
 }
 if(/repeat (that|last) order|repeat order|read (the )?order|repeat everything/.test(said)){repeatLastOrder();return;}
 const m=said.match(/(?:read|repeat) (?:item|hot dog|hot dawg) (one|two|three|four|five|\d+)/);
 if(m&&lastSpokenOrderId){const words={one:1,two:2,three:3,four:4,five:5};const n=words[m[1]]||Number(m[1]);speakKitchenOrder(lastSpokenOrderId,n-1);}
}
function startKitchenListening(){
 clearTimeout(kitchenPauseTimer);
 if(window.BakersDawgsAndroid&&typeof window.BakersDawgsAndroid.startListening==="function"){
  kitchenListening=true;voiceStatus("Starting microphone…");window.BakersDawgsAndroid.startListening();return;
 }
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){voiceStatus("Voice commands are unavailable in this browser. Read Order buttons may still work.");return;}
 if(!kitchenRecognition){
  kitchenRecognition=new SR(); kitchenRecognition.lang="en-US"; kitchenRecognition.continuous=true; kitchenRecognition.interimResults=false;
  kitchenRecognition.onresult=e=>Array.from(e.results).slice(e.resultIndex).forEach(r=>handleKitchenCommand(r[0].transcript));
  kitchenRecognition.onstart=()=>{kitchenStarting=false;kitchenRecognizing=true;};
  kitchenRecognition.onend=()=>{kitchenStarting=false;kitchenRecognizing=false;if(kitchenListening)setTimeout(()=>startKitchenListening(),250);};
  kitchenRecognition.onerror=e=>{if(e.error==="not-allowed"){kitchenListening=false;voiceStatus("Microphone permission is off.");}};
 }
 if(kitchenRecognizing||kitchenStarting){voiceStatus("Already listening for kitchen commands");return;}
 kitchenListening=true;kitchenStarting=true;
 try{kitchenRecognition.start();voiceStatus("Listening for kitchen commands");}
 catch(e){kitchenStarting=false;if(String(e?.message||"").includes("already started")){kitchenRecognizing=true;voiceStatus("Already listening for kitchen commands");}else voiceStatus("Could not start microphone: "+e.message);}
}
function stopKitchenListening(message="Voice assistant paused."){
 kitchenListening=false;kitchenStarting=false;clearTimeout(kitchenPauseTimer);
 if(window.BakersDawgsAndroid&&typeof window.BakersDawgsAndroid.stopListening==="function")window.BakersDawgsAndroid.stopListening();
 if(kitchenRecognition){try{kitchenRecognition.stop();}catch(e){}}
 voiceStatus(message);
}
function pauseKitchenListening(minutes){
 stopKitchenListening(`Paused for ${minutes} minutes`);
 kitchenPauseTimer=setTimeout(()=>startKitchenListening(),minutes*60000);
}


async function changeStatus(id,status){
 const order=(window.bdCurrentOrders||[]).find(o=>String(o.id)===String(id));
 if(status==="Completed" && order && !order.payment_method){
  alert("Select how the customer paid before completing this order.");
  return;
 }
 try{
  await bdUpdateOrder(id,{status});
  await loadOrders();
 }catch(e){
  alert("Could not update order.");
 }
}

async function deleteOrder(id){
 if(!confirm("Delete this order?")) return;

 try{
  await bdDeleteOrder(id);
  await loadOrders();
 }catch(e){
  alert("Could not delete order.");
 }
}

function toggleCompleted(){
 hideCompleted=!hideCompleted;
 const btn=document.querySelector("#completedToggle");
 if(btn) btn.textContent=hideCompleted?"Show Completed":"Hide Completed";
 loadOrders();
}

function filterOrders(status){
 currentFilter=status;
 if(status==="Completed"&&hideCompleted){
  hideCompleted=false;
  const btn=document.querySelector("#completedToggle");
  if(btn) btn.textContent="Hide Completed";
 }
 loadOrders();
}

const recoveryToken=bdRecoveryToken();
if(recoveryToken){
 const loginBox=document.querySelector("#login");
 const recoveryBox=document.querySelector("#recovery");
 if(loginBox) loginBox.style.display="none";
 if(recoveryBox){ recoveryBox.classList.remove("hidden"); recoveryBox.style.display="grid"; }
 const save=document.querySelector("#savePasswordBtn");
 if(save) save.onclick=async function(){
  const p=document.querySelector("#newPassword").value;
  const c=document.querySelector("#confirmPassword").value;
  if(p.length<8){ alert("Use at least 8 characters."); return; }
  if(p!==c){ alert("Passwords do not match."); return; }
  save.disabled=true;
  try{
   await bdUpdatePassword(recoveryToken,p);
   history.replaceState(null,"",location.pathname);
   alert("Password updated. Sign in with your new password.");
   location.reload();
  }catch(e){
   save.disabled=false;
   alert("Could not update password. Request a new reset link and try again.");
  }
 };
}else if(bdHasSavedSession()){
 // On devices without a usable passkey, keep the trusted Supabase session signed in
 // so staff do not have to re-enter the password every time the app opens.
 (async()=>{
  if(await bdRefreshSession()){
   sessionStorage.removeItem("bdReturnToAdmin");
   showPinGate();
  }
 })();
}

setInterval(()=>{
 if(bdHasSavedSession()){
  loadOrders();
 }
},5000);

const loginBtn=document.querySelector("#loginBtn");
if(loginBtn){ loginBtn.onclick=async function(e){ e.preventDefault(); await login(); }; }
const forgotBtn=document.querySelector("#forgotBtn");
if(forgotBtn){ forgotBtn.onclick=async function(e){ e.preventDefault(); await forgotPassword(); }; }
const passwordInput=document.querySelector("#password");
if(passwordInput) passwordInput.addEventListener("keydown",e=>{if(e.key==="Enter") login();});

const pinUnlockBtn=document.querySelector("#pinUnlockBtn");
if(pinUnlockBtn)pinUnlockBtn.onclick=unlockWithPin;
const staffPinInput=document.querySelector("#staffPin");
if(staffPinInput)staffPinInput.addEventListener("keydown",e=>{if(e.key==="Enter")unlockWithPin();});
