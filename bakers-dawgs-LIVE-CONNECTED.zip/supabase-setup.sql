-- Run this once in your Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  customer_name text not null,
  phone text not null,
  pickup_time text not null,
  notes text default '',
  items jsonb not null,
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'New' check (status in ('New','Accepted','Cooking','Ready','Completed'))
);
alter table public.orders enable row level security;

-- Customer browsers may create orders.
create policy "public can create orders" on public.orders for insert to anon with check (status='New');

-- NOTE: For a truly secure production admin, reads/updates/deletes should use Supabase Auth.
-- This self-run starter permits the browser admin board to manage orders using the anon key.
create policy "admin board can read orders" on public.orders for select to anon using (true);
create policy "admin board can update orders" on public.orders for update to anon using (true) with check (true);
create policy "admin board can delete orders" on public.orders for delete to anon using (true);
