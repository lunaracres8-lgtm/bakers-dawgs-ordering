const ADMIN_PIN="2468"; let filter="all",cache=[];
const statuses=["New","Accepted","Cooking","Ready","Completed"],loginEl=document.querySelector("#login");
function login(){if(pin.value!==ADMIN_PIN)return alert("Incorrect PIN");sessionStorage.setItem("bdAdmin","1");showApp()}
function logout(){sessionStorage.removeItem("bdAdmin");location.reload()}
function money(n){return "$"+Number(n).toFixed(2)}
async function showApp(){loginEl.classList.add("hidden");app.classList.remove("hidden");await render();setInterval(render,5000)}
async function render(){try{cache=await bdGetOrders()}catch(e){orders.innerHTML='<div class="empty">Shared database is not configured yet. Add the two Supabase values to config.js.</div>';return}
let shown=filter==="all"?cache:cache.filter(o=>o.status===filter);openCount.textContent=cache.filter(o=>o.status!=="Completed").length;
orders.innerHTML=shown.length?shown.map(o=>`<article class="order ${o.status==="New"?"new":""}"><div class="orderhead"><b>ORDER #${String(o.id).slice(0,8)}</b><span class="badge">${o.status}</span></div><div class="orderbody"><div class="customer">${esc(o.customer_name)}</div><div class="meta">${esc(o.phone)} • Pickup ${esc(o.pickup_time)}</div>${(o.items||[]).map(x=>`<div class="line"><div><b>${esc(x.name)}</b><small>${esc([x.options,x.notes].filter(Boolean).join(" • "))}</small></div><b>${money(x.price)}</b></div>`).join("")}<div class="total"><span>Total</span><span>${money(o.total)}</span></div>${o.notes?`<div class="notes"><b>Order note:</b> ${esc(o.notes)}</div>`:""}<div class="actions">${statuses.map(s=>`<button class="${s==="Ready"?"primary":""}" onclick="setStatus('${o.id}','${s}')">${s}</button>`).join("")}<button onclick="removeOrder('${o.id}')">Delete</button></div></div></article>`).join(""):'<div class="empty">No orders in this view.</div>'}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function setStatus(id,s){await bdStatus(id,s);render()} async function removeOrder(id){if(confirm("Delete this order?")){await bdDelete(id);render()}}
function filterOrders(s){filter=s;render()} async function clearCompleted(){for(const o of cache.filter(x=>x.status==="Completed"))await bdDelete(o.id);render()}
function seedDemo(){alert("Use the customer ordering page to send a real test order.")}
setInterval(()=>clock.textContent=new Date().toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}),1000);
if(sessionStorage.getItem("bdAdmin")==="1")showApp();