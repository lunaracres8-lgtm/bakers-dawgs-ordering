const BD=window.BD_CONFIG||{};
const configured=BD.SUPABASE_URL && !BD.SUPABASE_URL.startsWith("PASTE_") && BD.SUPABASE_ANON_KEY && !BD.SUPABASE_ANON_KEY.startsWith("PASTE_");
const api=(path,opt={})=>fetch(BD.SUPABASE_URL+"/rest/v1/"+path,{...opt,headers:{apikey:BD.SUPABASE_ANON_KEY,Authorization:"Bearer "+BD.SUPABASE_ANON_KEY,"Content-Type":"application/json",Prefer:opt.prefer||"",...(opt.headers||{})}});
async function bdCreateOrder(order){if(!configured)throw Error("ONLINE_SETUP_REQUIRED");let r=await api("orders",{method:"POST",prefer:"return=representation",body:JSON.stringify(order)});if(!r.ok)throw Error(await r.text());return (await r.json())[0]}
async function bdGetOrders(){if(!configured)return [];let r=await api("orders?select=*&order=created_at.desc");if(!r.ok)throw Error(await r.text());return r.json()}
async function bdStatus(id,status){let r=await api("orders?id=eq."+encodeURIComponent(id),{method:"PATCH",body:JSON.stringify({status})});if(!r.ok)throw Error(await r.text())}
async function bdDelete(id){let r=await api("orders?id=eq."+encodeURIComponent(id),{method:"DELETE"});if(!r.ok)throw Error(await r.text())}
